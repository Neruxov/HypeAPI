import requests

class GuildPlayer:
    def __init__(self, data):
        self.data = data

    def getRank(self):

