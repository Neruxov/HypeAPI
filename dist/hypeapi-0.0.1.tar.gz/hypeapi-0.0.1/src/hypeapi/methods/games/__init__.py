from bedwars import BedWars
from skywars import SkyWars